# Strona Anny Sarafin — instrukcja wdrożenia (GitHub Pages + Web3Forms)

## Pliki w paczce

- `index.html` — strona główna
- `dziekuje.html` — potwierdzenie po wysłaniu formularza
- `README.md` — ten plik

## 1. Wstaw klucz Web3Forms (1 minuta)

Otwórz `index.html` w notatniku / Notepad++ / VS Code i znajdź linię:

```html
<input type="hidden" name="access_key" value="TWOJ_KLUCZ_TUTAJ">
```

Podmień `TWOJ_KLUCZ_TUTAJ` na swój klucz z Web3Forms (ten, który już masz). Zapisz plik.

## 2. Publikacja na GitHub Pages (5–10 minut)

### Wariant A — czyste konto (jeśli to Twoja pierwsza strona na GitHubie)

1. Zaloguj się na github.com.
2. Kliknij **+** (prawy górny róg) → **New repository**.
3. **Repository name:** wpisz `USERNAME.github.io` — gdzie USERNAME to Twój login GitHub (np. `annasarafin.github.io`). Dzięki temu URL strony będzie po prostu `https://annasarafin.github.io` — bez żadnego sufiksu.
4. **Public** (musi być publiczne dla darmowego GitHub Pages).
5. Zaznacz **Add a README file**.
6. **Create repository**.
7. W nowym repozytorium kliknij **Add file → Upload files**.
8. Przeciągnij `index.html` i `dziekuje.html` na okno (bez folderu — same pliki).
9. Na dole strony kliknij **Commit changes**.
10. Wejdź w **Settings → Pages** (lewe menu). W sekcji "Build and deployment" wybierz Source: **Deploy from a branch**, Branch: **main**, folder: **/ (root)** → **Save**.
11. Czekaj ~1 minutę. Strona ruszy pod adresem `https://USERNAME.github.io`.

### Wariant B — chcesz strona w podkatalogu (np. `username.github.io/sarafin/`)

W kroku 3 nazwij repo dowolnie (np. `sarafin`). URL będzie wtedy `https://USERNAME.github.io/sarafin/`. Reszta tak samo.

## 3. Test formularza

1. Wejdź na opublikowaną stronę.
2. Wyślij testową wiadomość przez formularz (możesz na własny adres).
3. Sprawdź skrzynkę `annasiudaj@gmail.com` — wiadomość powinna dotrzeć natychmiast.
4. Po wysłaniu strona automatycznie przekieruje na `dziekuje.html`.

Jeśli coś nie zadziała — strona pokaże komunikat o błędzie z linkiem do bezpośredniego maila.

## 4. (Opcjonalnie) Ogranicz klucz do swojej domeny

Po wdrożeniu wejdź na panel Web3Forms i w ustawieniach klucza dodaj swoją domenę do dozwolonych (np. `USERNAME.github.io`). Wtedy nikt nie skopiuje Twojego klucza i nie użyje go na innej stronie.

## 5. Aktualizacja strony w przyszłości

GitHub Pages odświeża się automatycznie po każdej zmianie pliku w repozytorium. Możesz edytować pliki bezpośrednio przez GitHub (klikając na plik i ikonę ołówka) albo wgrać nowsze wersje przez **Add file → Upload files** (nadpisze stare).

## 6. Własna domena (np. `annasarafin.pl`) — opcjonalnie

Jeśli kupisz domenę:
1. W Settings → Pages → Custom domain wpisz `annasarafin.pl` → Save.
2. U rejestratora domeny (np. nazwa.pl, OVH) ustaw rekord CNAME wskazujący na `USERNAME.github.io`.
3. Po kilku godzinach (propagacja DNS) strona zacznie działać pod nową domeną.
4. W panelu Web3Forms zaktualizuj listę dozwolonych domen (dodaj `annasarafin.pl`).

## Pytania, problemy

Zgłoś — chętnie pomogę.
